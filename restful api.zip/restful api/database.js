const{ createPool
 }=require('mysql');
 const express=require('express')
 const app=express();
 app.use(express.json());

 const pool=createPool({
     host:"localhost",
     user:"root",
     password:"Rbic#123",
     database:"amrish",
     connectionLimit:10
 });
// get method
 pool.query('select*from data where uid=?','59e7615c-c162-11ec-8a93-98e7f4f2f97c',(err,result,fields)=>{
     if(err){
         return console.log(err);
     }
     return console.log(result);
 });
 module.exports=pool
